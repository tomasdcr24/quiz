const fs = require("fs");
const csv = require("csv-parser");

const questions = [];

fs.createReadStream("questions.csv") // Path to your CSV file
  .pipe(csv({ separator: ";" })) // Set separator to semicolon
  .on("data", (row) => {
    const { Subject, Number, Question, A, B, C, D, Correct } = row;

    // Create an object with question data
    const questionData = {
      subject: Subject,
      number: parseInt(Number),
      question: Question,
      answers: [A, B, C, D],
      correct: getCorrectAnswer(Correct, [A, B, C, D]), // Get the correct answer based on the Correct column
    };

    // Push the question object into the questions array
    questions.push(questionData);
  })
  .on("end", () => {
    // After reading the CSV, print the questions (you can replace this with saving to a file)
    console.log(questions);

    // Optionally, write the questions array to a JS file for use in your application
    fs.writeFileSync(
      "questions.js",
      `const questions = ${JSON.stringify(questions, null, 2)};`
    );
  });

// Helper function to return the correct answer based on the letter
function getCorrectAnswer(correctLetter, answers) {
  const answerMap = {
    A: answers[0],
    B: answers[1],
    C: answers[2],
    D: answers[3],
  };

  return answerMap[correctLetter] || ""; // If the correct letter is not valid, return an empty string
}
