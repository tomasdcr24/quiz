let selectedQuestions = [];
let currentQuestionIndex = 0;
let totalQuestions = 50;
let correctAnswers = 0;
let startTime;
let timerInterval;
let saveCounter = 0;

document.querySelectorAll(".num-questions").forEach((button) => {
  button.addEventListener("click", function () {
    totalQuestions = parseInt(this.dataset.value);
    startQuiz();
    document.querySelector(".start-screen").classList.add("hidden");
    document.querySelector(".quiz").classList.remove("hidden");
  });
});

document.querySelector(".restart-btn").addEventListener("click", function () {
  correctAnswers = 0;
  currentQuestionIndex = 0;
  selectedQuestions = [];

  localStorage.removeItem("quizProgress");
  document.getElementById("progress-bar").value = 0;

  clearInterval(timerInterval);

  document.querySelector(".result-screen").classList.add("hidden");
  document.querySelector(".start-screen").classList.remove("hidden");
});

function shuffleArray(array) {
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
}

function startQuiz() {
  const savedProgress = localStorage.getItem("quizProgress");

  if (savedProgress) {
    const confirmResume = confirm(
      "Would you like to resume your previous quiz?"
    );
    if (confirmResume) {
      const savedData = JSON.parse(savedProgress);

      if (savedData.currentQuestionIndex < savedData.selectedQuestions.length) {
        restoreProgress();
        return;
      } else {
        localStorage.removeItem("quizProgress");
      }
    } else {
      localStorage.removeItem("quizProgress");
    }
  }

  if (typeof questions === "undefined" || questions.length === 0) {
    console.error("Error: No questions available!");
    return;
  }

  shuffleArray(questions);
  selectedQuestions = questions.slice(0, totalQuestions);
  currentQuestionIndex = 0;
  correctAnswers = 0;

  startTime = Date.now();
  timerInterval = setInterval(updateClock, 1000);
  loadQuestion();

  const nextBtn = document.querySelector(".next-btn");
  nextBtn.removeEventListener("click", nextQuestion);
  nextBtn.addEventListener("click", nextQuestion);
}

function loadQuestion() {
  const questionElement = document.getElementById("question");
  const subjectElement = document.getElementById("subject");
  const answerButtons = document.getElementById("answer-buttons");

  const currentQuestion = selectedQuestions[currentQuestionIndex];
  const currentQuestionText = document.getElementById("current-question");

  currentQuestionText.innerText = `${currentQuestionIndex + 1} of ${
    selectedQuestions.length
  }`;

  const progressBar = document.getElementById("progress-bar");
  const progressValue =
    ((currentQuestionIndex + 1) / selectedQuestions.length) * 100;
  progressBar.value = progressValue;

  subjectElement.innerText = currentQuestion.subject;
  questionElement.innerText = currentQuestion.question;

  answerButtons.innerHTML = "";

  shuffleArray(currentQuestion.answers);

  currentQuestion.answers.forEach((answer) => {
    const button = document.createElement("button");
    button.classList.add("btn");
    button.innerText = answer;

    if (currentQuestion.answered) {
      button.disabled = true;

      if (currentQuestion.selectedAnswer === answer) {
        button.classList.add(
          currentQuestion.selectedAnswer === currentQuestion.correct
            ? "correct"
            : "incorrect"
        );
      }

      if (
        answer === currentQuestion.correct &&
        currentQuestion.selectedAnswer !== currentQuestion.correct
      ) {
        button.classList.add("correct");
      }
    }

    button.addEventListener("click", function () {
      selectAnswer(button, answer);
    });

    answerButtons.appendChild(button);
  });

  document.querySelector(".next-btn").disabled =
    !currentQuestion.selectedAnswer;
}

function saveProgress() {
  const currentTime = Date.now();
  const elapsedTime = currentTime - startTime;

  const progressData = {
    selectedQuestions,
    currentQuestionIndex,
    correctAnswers,
    pauseTime: currentTime,
    elapsedTime,
    answeredQuestions: selectedQuestions.map((question, index) => {
      return {
        answered: question.answered || false,
        userAnswer: question.userAnswer || null,
      };
    }),
  };

  localStorage.setItem("quizProgress", JSON.stringify(progressData));
}

function restoreProgress() {
  const savedProgress = JSON.parse(localStorage.getItem("quizProgress"));

  if (savedProgress) {
    selectedQuestions = savedProgress.selectedQuestions;
    currentQuestionIndex = savedProgress.currentQuestionIndex;
    correctAnswers = savedProgress.correctAnswers;

    savedProgress.answeredQuestions.forEach((answeredQuestion, index) => {
      if (answeredQuestion.answered) {
        selectedQuestions[index].answered = true;
        selectedQuestions[index].userAnswer = answeredQuestion.userAnswer;
      }
    });

    startTime = Date.now() - savedProgress.elapsedTime;
    loadQuestion();
    clearInterval(timerInterval);

    const nextBtn = document.querySelector(".next-btn");
    nextBtn.removeEventListener("click", nextQuestion);
    nextBtn.addEventListener("click", nextQuestion);

    timerInterval = setInterval(updateClock, 1000);
  }
}

function selectAnswer(button, answer) {
  const currentQuestion = selectedQuestions[currentQuestionIndex];
  const answerButtons = document.querySelectorAll(".btn");

  answerButtons.forEach((btn) => {
    btn.disabled = true;
  });

  currentQuestion.selectedAnswer = answer;
  currentQuestion.answered = true;

  if (answer === currentQuestion.correct) {
    button.classList.add("correct");
    correctAnswers++;
  } else {
    button.classList.add("incorrect");
    answerButtons.forEach((btn) => {
      if (btn.innerText === currentQuestion.correct) {
        btn.classList.add("correct");
      }
    });
  }

  document.querySelector(".next-btn").disabled = false;

  saveProgress();
}

function nextQuestion() {
  currentQuestionIndex++;
  saveProgress();

  if (currentQuestionIndex < selectedQuestions.length) {
    loadQuestion();
  } else {
    showResults();
    clearInterval(timerInterval);
  }
}

function updateClock() {
  if (!startTime) return;

  saveCounter++;
  if (saveCounter % 5 === 0) {
    saveProgress();
  }

  const elapsedTime = Date.now() - startTime;
  const seconds = Math.floor(elapsedTime / 1000);
  const minutes = Math.floor(seconds / 60);
  const remainingSeconds = seconds % 60;

  document.getElementById("clock").textContent = `${minutes}:${
    remainingSeconds < 10 ? "0" : ""
  }${remainingSeconds}`;
}

function showResults() {
  clearInterval(timerInterval);

  localStorage.removeItem("quizProgress");

  const elapsedTime = Date.now() - startTime;
  const seconds = Math.floor(elapsedTime / 1000);
  const minutes = Math.floor(seconds / 60);
  const remainingSeconds = seconds % 60;
  const formattedTime = `${minutes}:${
    remainingSeconds < 10 ? "0" : ""
  }${remainingSeconds}`;
  document.querySelector(".quiz").classList.add("hidden");
  document.querySelector(".result-screen").classList.remove("hidden");
  document.getElementById("score").innerText = correctAnswers;
  document.getElementById("total-questions").innerText =
    selectedQuestions.length;
  document.getElementById("time-taken").innerText = formattedTime;
}
